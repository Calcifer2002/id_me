package com.example.id_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
